"""Evaluation-only goal leases and online observed-map motion checks.

No reference geometry, gate coordinates or trained weights enter these helpers.
Mapper origins are voxel corners. Unknown cell centers are not traversable;
only an unknown cell containing the localized robot may be exempted in a copy.
"""
import heapq

import numpy as np
from scipy.ndimage import binary_dilation, distance_transform_edt, label
from scipy.spatial import cKDTree


class GoalLease:
    def __init__(self, arrival_radius=.2, max_intervals=4):
        self.arrival_radius = arrival_radius
        self.max_intervals = max_intervals
        self.goal = None
        self.execution_goal = None
        self.age = 0

    def choose(self, pose, proposal):
        if (self.goal is not None and self.age < self.max_intervals
                and np.linalg.norm(np.asarray(pose)-self.execution_goal) > self.arrival_radius):
            self.age += 1
            return self.goal.copy(), True
        self.goal = np.asarray(proposal, dtype=float).copy()
        self.execution_goal = self.goal.copy()
        self.age = 1
        return self.goal.copy(), False

    def release(self):
        self.goal = None
        self.execution_goal = None
        self.age = 0

    def set_execution_goal(self, point):
        self.execution_goal=np.asarray(point,dtype=float).copy()


class ObservedSpace:
    def __init__(self, data, origin, resolution, actual_pose=None,
                 mapping_sensor_position=None, sensor_mount_length=None,
                 clearance_model='conservative'):
        if clearance_model not in ('conservative','voxel_boxes'):
            raise ValueError('Unknown observed-voxel clearance model')
        self.clearance_model=clearance_model
        self.data = np.asarray(data).copy()
        self.origin = np.asarray(origin, dtype=float)
        self.resolution = float(resolution)
        self.shape = np.array(self.data.shape)
        self.mount_anchor_cells = 0
        if (actual_pose is not None and mapping_sensor_position is not None
                and sensor_mount_length is not None):
            from rsl_rl.runners.utils import Map, anchor_rigid_sensor_mount
            planning=Map(self.origin,self.resolution,self.data,self.shape,origin_kind='corner')
            before=int(np.count_nonzero(self.data==-1))
            anchor_rigid_sensor_mount(planning,np.asarray(actual_pose),
                                      np.asarray(mapping_sensor_position),float(sensor_mount_length))
            self.mount_anchor_cells=before-int(np.count_nonzero(self.data==-1))
        if actual_pose is not None:
            own = self.indices(actual_pose)[0]
            if self.in_bounds(own) and self.data[tuple(own)] == -1:
                self.data[tuple(own)] = 0
        occupied = np.argwhere(self.data == 1)
        centers = self.origin + (occupied+.5)*self.resolution
        self.occupied_tree = cKDTree(centers) if len(centers) else None
        self.half_diagonal = np.sqrt(3)*self.resolution/2
        self._node_clearance = None
        self._free_margin = None
        self.last_route_status = None
        self.last_route_expansions = 0

    def indices(self, points):
        scaled = (np.atleast_2d(points)-self.origin)/self.resolution
        return np.floor(np.round(scaled, 6)).astype(int)

    def in_bounds(self, index):
        return bool(np.all(index >= 0) and np.all(index < self.shape))

    def points_clear(self, points, margin=0.):
        points = np.atleast_2d(points)
        indices = self.indices(points)
        if np.any(indices < 0) or np.any(indices >= self.shape):
            return False
        if np.any(self.data[tuple(indices.T)] != 0):
            return False
        if margin > 0 and self.occupied_tree is not None:
            if self.clearance_model=='voxel_boxes':
                neighbors=self.occupied_tree.query_ball_point(points,margin+self.half_diagonal+1e-9)
                for point,ids in zip(points,neighbors):
                    if not ids:continue
                    delta=np.maximum(np.abs(self.occupied_tree.data[ids]-point)-self.resolution/2,0)
                    if np.any(np.linalg.norm(delta,axis=1)<margin-1e-9):return False
                return True
            distances = self.occupied_tree.query(points, k=1)[0]-self.half_diagonal
            if np.any(distances < margin-1e-9):
                return False
        return True

    def segment_clear(self, start, end, margin=0.):
        start = np.asarray(start); end = np.asarray(end)
        # Partition at every voxel-plane crossing. Midpoints visit every
        # positive-length intersected voxel, even a chord shorter than a sample.
        delta = end-start
        times = [0.,1.]
        for axis in range(3):
            if abs(delta[axis]) < 1e-12:continue
            low,high=sorted([start[axis],end[axis]])
            planes=self.origin[axis]+np.arange(int(np.floor((low-self.origin[axis])/self.resolution))+1,
                                              int(np.ceil((high-self.origin[axis])/self.resolution)))*self.resolution
            times.extend(((planes-start[axis])/delta[axis]).tolist())
        times=np.unique(np.clip(times,0,1))
        probes=np.concatenate((times,(times[:-1]+times[1:])/2))
        indices=np.floor((start+probes[:,None]*delta-self.origin)/self.resolution).astype(int)
        if np.any(indices<0) or np.any(indices>=self.shape) or np.any(self.data[tuple(indices.T)]!=0):
            return False
        if margin<=0:return True
        if self.clearance_model=='voxel_boxes':
            if self.occupied_tree is None:return True
            centers=self.occupied_tree.data[self.occupied_tree.query_ball_point(
                (start+end)/2,np.linalg.norm(end-start)/2+margin+self.half_diagonal+1e-9)]
            if not len(centers):return True
            lower=centers-self.resolution/2;upper=centers+self.resolution/2
            # Squared point-to-box distance is quadratic between the six box
            # coordinate-plane crossings. Minimize each interval analytically.
            cuts=np.zeros((len(centers),8));cuts[:,1]=1.
            for axis in range(3):
                if abs(delta[axis])>1e-12:
                    cuts[:,2+2*axis]=np.clip((lower[:,axis]-start[axis])/delta[axis],0,1)
                    cuts[:,3+2*axis]=np.clip((upper[:,axis]-start[axis])/delta[axis],0,1)
            cuts.sort(axis=1);minimum=np.full(len(centers),np.inf)
            for i in range(7):
                a,b=cuts[:,i],cuts[:,i+1];mid=start+(a+b)[:,None]/2*delta
                low=mid<lower;high=mid>upper
                slope=np.where(low|high,delta,0)
                constant=np.where(low,start-lower,np.where(high,start-upper,0))
                denom=np.sum(slope*slope,axis=1)
                optimum=np.divide(-np.sum(slope*constant,axis=1),denom,
                                  out=a.copy(),where=denom>0)
                optimum=np.clip(optimum,a,b);point=start+optimum[:,None]*delta
                distance=np.linalg.norm(np.maximum(np.maximum(lower-point,point-upper),0),axis=1)
                minimum=np.minimum(minimum,distance)
            return bool(np.all(minimum>=margin-1e-9))
        count = max(2, int(np.ceil(np.linalg.norm(end-start)/(.25*self.resolution)))+1)
        # Center-distance lower bounds are 1-Lipschitz. The half sample spacing
        # covers the clearance change between consecutive sampled positions.
        spacing=np.linalg.norm(end-start)/(count-1)
        return self.points_clear(np.linspace(start, end, count), margin+spacing/2)

    def route(self, start, goal, margin=.4, max_expansions=20000, project_goal_radius=0.):
        self.last_route_status='endpoint_not_clear';self.last_route_expansions=0
        start = np.asarray(start, dtype=float); goal = np.asarray(goal, dtype=float)
        if not self.points_clear(start, margin):
            return None
        if not self.points_clear(goal, margin):
            if project_goal_radius<=0 or not self.points_clear(goal):return None
            index=self.indices(goal)[0];radius=int(np.ceil(project_goal_radius/self.resolution))
            offsets=np.stack(np.meshgrid(*[np.arange(-radius,radius+1)]*3,indexing='ij'),axis=-1).reshape(-1,3)
            candidates=self.origin+(index+offsets+.5)*self.resolution
            distances=np.linalg.norm(candidates-goal,axis=1)
            safe=next((candidates[i] for i in np.argsort(distances)
                       if distances[i]<=project_goal_radius+1e-9 and self.points_clear(candidates[i],margin)),None)
            if safe is None:return None
            goal=safe
        if self.segment_clear(start, goal, margin):
            self.last_route_status='direct'
            return np.array([start, goal])
        if self._node_clearance is None and self.clearance_model=='conservative':
            self._node_clearance = (distance_transform_edt(self.data != 1)*self.resolution
                                    - self.half_diagonal) if self.occupied_tree is not None else np.full(self.data.shape, np.inf)
        if self._free_margin!=margin:
            if self.clearance_model=='voxel_boxes':
                radius=int(np.ceil((margin+self.half_diagonal)/self.resolution))
                offsets=np.stack(np.meshgrid(*[np.arange(-radius,radius+1)]*3,indexing='ij'),axis=-1)
                distances=np.linalg.norm(np.maximum(np.abs(offsets)*self.resolution-self.resolution/2,0),axis=-1)
                forbidden=binary_dilation(self.data==1,structure=distances<margin-1e-9)
                self._free=(self.data==0)&~forbidden
            else:
                self._free=(self.data == 0) & (self._node_clearance >= margin-1e-9)
            self._components,_=label(self._free);self._free_margin=margin
        free=self._free
        first, last = [tuple(i) for i in self.indices([start, goal])]
        if not free[first] or not free[last]:
            self.last_route_status='endpoint_center_not_clear'
            return None
        if self._components[first]!=self._components[last]:
            self.last_route_status='disconnected_free_voxels'
            return None
        center = lambda index: self.origin+(np.asarray(index)+.5)*self.resolution
        if not self.segment_clear(start, center(first), margin) or not self.segment_clear(center(last), goal, margin):
            self.last_route_status='endpoint_attachment_not_clear'
            return None
        queue = [(float(np.linalg.norm(np.array(first)-last)), 0., first)]
        costs = {first: 0.}; parent = {}; expanded = 0
        while queue and expanded < max_expansions:
            _, cost, node = heapq.heappop(queue)
            if cost > costs[node]:
                continue
            if node == last:
                nodes = [last]
                while nodes[-1] != first:
                    nodes.append(parent[nodes[-1]])
                raw = np.vstack([start, [center(n) for n in reversed(nodes)], goal])
                # Only remove bends when the true-pose connection is checked.
                result = [raw[0]]; i = 0
                while i < len(raw)-1:
                    j = len(raw)-1
                    while j > i+1 and not self.segment_clear(raw[i], raw[j], margin):
                        j -= 1
                    if not self.segment_clear(raw[i], raw[j], margin):
                        self.last_route_status='shortcut_not_clear'
                        return None
                    result.append(raw[j]); i = j
                self.last_route_status='routed';self.last_route_expansions=expanded
                return np.asarray(result)
            expanded += 1
            for axis in range(3):
                for direction in (-1, 1):
                    adjacent = list(node); adjacent[axis] += direction
                    adjacent = tuple(adjacent)
                    if not self.in_bounds(np.array(adjacent)) or not free[adjacent]:
                        continue
                    candidate = cost+1
                    if candidate < costs.get(adjacent, np.inf):
                        costs[adjacent] = candidate; parent[adjacent] = node
                        heuristic = float(np.linalg.norm(np.array(adjacent)-last))
                        heapq.heappush(queue, (candidate+heuristic, candidate, adjacent))
        self.last_route_status='expansion_budget' if queue else 'search_exhausted'
        self.last_route_expansions=expanded
        return None

    def command(self, path, lookahead=.8):
        if len(path)==2:
            return path[-1].copy()
        start = path[0]
        following = next((p for p in path[1:] if np.linalg.norm(p-start) > 1e-6), path[-1])
        distance = np.linalg.norm(following-start)
        return start+(following-start)*min(1., lookahead/max(distance, 1e-9))


def pose_action_mask(observation, extras, space, pose):
    """Mask actual-pose-invalid candidates; leave model and graph unchanged."""
    import torch
    mask = observation['neighboring_padding_mask'].clone()
    indices = extras['current_edges'][0, :, 0].numpy()
    coordinates = extras['local_node_coords'][0].numpy()
    tested = 0; rejected = 0
    for slot in np.flatnonzero(~mask[0, 0].numpy()):
        tested += 1
        if not space.segment_clear(pose, coordinates[indices[slot]]):
            mask[0, 0, slot] = True; rejected += 1
    observation['neighboring_padding_mask'] = mask
    extras['pose_mask_tested'] = torch.tensor([tested])
    extras['pose_mask_rejected'] = torch.tensor([rejected])
    extras['pose_mask_available'] = torch.tensor([tested-rejected])
    return observation, extras
